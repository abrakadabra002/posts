<?php $__env->startSection('content'); ?>
    <div class="container form-container">
        <?php if(auth()->guard()->check()): ?>
        <form action="" method="POST" class="form">
            <?php echo csrf_field(); ?>
            <h2 class="form__title">Изменить пароль</h2>
            <?php if(session('success')): ?>
                <div class="success" style="margin-bottom: 10px">Пароль успешно изменен</div>
            <?php endif; ?>
            <input type="password" name="last-password" placeholder="Предыдущий пароль" class="form__input <?php $__errorArgs = ['last-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('last-password')); ?>">
            <input type="password" name="new-password" placeholder="Новый пароль" class="form__input <?php $__errorArgs = ['new-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('new-password')); ?>">
            <input type="password" name="new-password_confirmation" placeholder="Повторите новый пароль" class="form__input <?php $__errorArgs = ['new-password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('new-password_confirmation')); ?>">
            <?php if($errors): ?>
                <ul class="errors-list">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="errors-list__item"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            <button type="submit" class="form__button">Сохранить</button>
        </form>
        <a href="<?php echo e(route('account')); ?>" class="guest-link form-link">Назад в профиль</a>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="<?php echo e(route('home')); ?>" class="guest-link">&larr; На главную</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/user/reset.blade.php ENDPATH**/ ?>