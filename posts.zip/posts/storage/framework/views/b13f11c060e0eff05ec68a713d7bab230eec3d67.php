<?php $__env->startSection('content'); ?>
    <div class="container lk-container">
        <?php if(auth()->guard()->check()): ?>
            <div class="all-posts">
                <div class="top-section">
                    <h2 class="section-title">Мои посты</h2>
                </div>
                <?php if(session('delete')): ?>
                    <div class="error" style="margin-bottom: 10px">Пост удален</div>
                <?php endif; ?>
                <?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <img src="/public/storage/<?php echo e($post->image); ?>" alt="Картинка поста" class="post__image">
                        <h2 class="post__title"><?php echo e($post->title); ?></h2>
                        <p class="post__text"><?php echo e($post->text); ?></p>
                        <p class="post__publication">Опубликовано: <?php echo e($post->created_at); ?></p>
                        <div class="option-block">
                            <form action="<?php echo e(route('update', ['id' => $post->post_id])); ?>" method="GET">
                                <input type="hidden" name="id" value="<?php echo e($post->post_id); ?>">
                                <button type="submit" class="option-btn">&#9998;</button>
                            </form>
                            <form action="<?php echo e(route('delete')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($post->post_id); ?>">
                                <button type="submit" class="option-btn">&#10006;</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(!count($posts)): ?>
                    <div class="no-content">У вас нет созданных постов. <a href="<?php echo e(route('create')); ?>" class="guest-link">Создать сейчас</a></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="<?php echo e(route('home')); ?>" class="guest-link">&larr; На главную</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/post/all.blade.php ENDPATH**/ ?>