<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>myposts</title>
    <link rel="stylesheet" href="/resources/css/app.css">
</head>
<body>
    <header class="header">
        <div class="container">
            <a href="<?php echo e(route('home')); ?>"><h1 class="logo">myposts</h1></a>
            <nav class="menu">
                <a href="<?php echo e(route('home')); ?>" class="menu__item">Главная</a>
                <?php if(!Auth::user()): ?>
                    <a href="<?php echo e(route('login')); ?>" class="menu__item">Вход</a>
                    <a href="<?php echo e(route('registration')); ?>" class="menu__item">Регистрация</a>
                <?php endif; ?>
                <?php if(Auth::user()): ?>
                    <a href="<?php echo e(route('account')); ?>" class="menu__item">Аккаунт</a>
                    <a href="<?php echo e(route('logout')); ?>" class="menu__item">Выйти</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <section class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </section>
</body>
</html>
<?php /**PATH D:\OpenServer\domains\posts\resources\views/welcome.blade.php ENDPATH**/ ?>