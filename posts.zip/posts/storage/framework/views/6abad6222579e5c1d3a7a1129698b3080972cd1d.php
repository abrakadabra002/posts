<?php $__env->startSection('content'); ?>
    <div class="container">
        <br><br>
        <a href="<?php echo e(route('home')); ?>" class="guest-link">&larr; Назад</a>
        <h2 class="section-title" style="max-width: 70%"><?php echo e($post->title ?? ''); ?></h2>
        <br>
        <div class="post">
            <img src="/public/storage/<?php echo e($post->image); ?>" alt="Картинка поста" class="post__image">
            <br><br>
            <p class="post__text"><?php echo e($post->text); ?></p>
            <p class="post__publication">Автор: <?php echo e($post->email); ?></p>
            <p class="post__publication">Опубликовано: <?php echo e($post->created_at); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/post/post.blade.php ENDPATH**/ ?>