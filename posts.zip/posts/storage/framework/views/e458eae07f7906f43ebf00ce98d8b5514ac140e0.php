<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="section-title">О компании</h2>
        <p class="about">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Aliquid aspernatur autem consequatur fugit iste odit quidem. Doloribus eos,
            id natus quam reiciendis sed? Accusamus aliquam aliquid eum fugit maiores
            molestiae, mollitia nam officiis pariatur quam quo ratione reiciendis rem sit!
        </p>
        <h2 class="section-title">Новые посты</h2>
        <br>
        <?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post">
                <img src="/public/storage/<?php echo e($post->image); ?>" alt="Картинка поста" class="post__image">
                <h2 class="post__title"><?php echo e($post->title); ?></h2>
                <p class="post__text overflow-text"><?php echo e($post->text); ?></p>
                <p class="post__publication">Автор: <?php echo e($post->email); ?></p>
                <p class="post__publication">Опубликовано: <?php echo e($post->created_at); ?></p>
                <a href="<?php echo e(route('post', ['id' => $post->post_id])); ?>" class="about-link">Подробнее</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/home.blade.php ENDPATH**/ ?>