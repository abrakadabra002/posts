<?php $__env->startSection('content'); ?>
    <div class="container lk-container">
        <?php if(auth()->guard()->check()): ?>
        <div class="lk-form">
            <h2 class="section-title">Личный кабинет</h2>
            <form action="<?php echo e(route('edit')); ?>" method="POST" class="form edit-form">
                <?php echo csrf_field(); ?>
                <?php if(session('success')): ?>
                    <div class="success" style="margin-bottom: 15px">Изменения успешно сохранены</div>
                <?php endif; ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-element">
                        <div class="form-element__title">Адрес электронной почты</div>
                        <input type="text" class="form__input disabled-input" value="<?php echo e($user->email); ?>" disabled>
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Страна происхождения</div>
                        <select name="country" id="country" class="form__input">
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>" <?php echo e($country->id == $user->country_id ? 'selected' : ''); ?>><?php echo e($country->country); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Дата рождения</div>
                        <input type="date" name="birthdate" class="form__input" value="<?php echo e($user->birthdate); ?>">
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Наличие лицензии</div>
                        <input type="text" class="form__input disabled-input" value="<?php echo e($user->licence ? 'Лицензия активна' : ''); ?>" disabled>
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Наличие регистрации</div>
                        <input type="text" class="form__input disabled-input" value="<?php echo e($user->registration ? 'Зарегистрирован' : ''); ?>" disabled>
                    </div>
                    <button type="submit" class="form__button">Сохранить изменения &rarr;</button>
                    <br>
                    <a href="<?php echo e(route('reset')); ?>" class="guest-link">Изменить пароль</a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </form>
        </div>
        <div class="lk-actions">
            <a href="<?php echo e(route('create')); ?>" class="lk-actions__link">Создать пост &rarr;</a>
            <a href="<?php echo e(route('posts')); ?>" class="lk-actions__link">Мои посты &rarr;</a>
        </div>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="<?php echo e(route('home')); ?>" class="guest-link">&larr; На главную</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/user/account.blade.php ENDPATH**/ ?>