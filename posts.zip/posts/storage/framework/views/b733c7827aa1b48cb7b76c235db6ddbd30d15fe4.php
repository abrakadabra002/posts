<?php $__env->startSection('content'); ?>
    <div class="container form-container">
        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(route('post-edit')); ?>" method="POST" class="form large-form">
                <?php echo csrf_field(); ?>
                <?php if(session('update')): ?>
                    <div class="success" style="margin-bottom: 10px">Изменения сохранены.&nbsp;<a href="<?php echo e(route('posts')); ?>" class="redirect-link" style="color: #fff">Перейти к моим постам</a></div>
                <?php endif; ?>
                <input type="hidden" name="id" value="<?php echo e($post->post_id); ?>">
                <img src="/public/storage/<?php echo e($post->image); ?>" alt="Картинка поста" class="large-form__image">
                <input type="text" name="title" placeholder="Заголовок" class="form__input <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($post->title); ?>">
                <textarea name="text" placeholder="Описание" class="form__input form__area <?php $__errorArgs = ['text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e($post->text); ?></textarea>
                <?php if($errors): ?>
                    <ul class="errors-list">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="errors-list__item"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
                <button type="submit" class="form__button">Изменить</button>
            </form>
            <a href="<?php echo e(route('posts')); ?>" class="guest-link form-link">Мои посты</a>
        <?php endif; ?>

        <?php if(auth()->guard()->guest()): ?>
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="<?php echo e(route('home')); ?>" class="guest-link">&larr; На главную</a>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/post/update.blade.php ENDPATH**/ ?>