<?php $__env->startSection('content'); ?>
    <div class="container form-container">
        <form action="" method="POST" class="form" id="login-form">
            <?php echo csrf_field(); ?>
            <h2 class="form__title">Авторизация</h2>
            <input type="email" name="email" placeholder="Адрес электронной почты" class="form__input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>">
            <input type="password" name="password" placeholder="Пароль" class="form__input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> err-field <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('password')); ?>">
            <div class="error-block" style="display: none">fdgdf</div>
            <div class="more-action">
                <a href="<?php echo e(route('registration')); ?>" class="more-action__link">Зарегистрироваться</a>
            </div>
            <?php if($errors || session()->has('error')): ?>
                <ul class="errors-list">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="errors-list__item"><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(session()->has('error')): ?>
                        <li class="errors-list__item">Неверный логин или пароль</li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
            <button type="submit" class="form__button">Войти</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OpenServer\domains\posts\resources\views/user/login.blade.php ENDPATH**/ ?>