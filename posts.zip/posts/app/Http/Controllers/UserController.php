<?php

namespace App\Http\Controllers;

use App\Models\Country;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function loginPage()
    {
        return view('user.login');
    }
    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * Вход в профиль
     */
    public function login(Request $request)
    {
        $validation = Validator($request->all(), [
            'email' => 'required|min:6|max:60',
            'password' => 'required|min:8|max:30'
        ], [
            'required' => 'Поле :attribute обязательно для заполнения',
            'min' => 'Недопустимая длина для поля :attribute',
            'max' => 'Недопустимая длина для поля :attribute'
        ]);

        if(!$validation->fails()) {
            if(Auth::attempt($request->only('email', 'password'))) {
                $request->session()->regenerate();
                session(array('auth', true));

                return redirect()->route('account');
            }

            return back()->with('error', true)->withInput();
        }

        return back()->withErrors($validation)->withInput();
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * Регистрация
     */
    public function registration(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'email' => 'required|min:6|max:60|unique:users',
            'birthdate' => 'required',
            'country' => 'required',
            'licence' => 'required',
            'registration' => 'required',
            'password' => 'required|min:8|max:30|confirmed'
        ], [
            'required' => 'Поле :attribute обязательно для заполнения',
            'min' => 'Недопустимая длина для поля :attribute',
            'max' => 'Недопустимая длина для поля :attribute',
            'unique' => 'Данный :attribute уже используется',
            'confirmed' => 'Введенные пароли не совпадают'
        ]);

        if(!$validation->fails()) {
            $request->merge(['password' => Hash::make($request->input('password'))]);
            $request->merge(['country_id' => $request->input('country')]);

            User::create($request->all());

            return back()->with('registration', true);
        }

        return back()->withErrors($validation)->withInput();
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * Обновление данных в профиле
     */
    public function account(Request $request)
    {
        User::where('id', Auth::user()->id)
            ->update([
                'birthdate' => $request->input('birthdate'),
                    'country_id' => $request->input('country')
                ]);

        return back()->with('success', true);
    }

    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     * Вывод страницы аккаунт пользователя
     */
    public function accountPage()
    {
        $user = User::where('users.id', Auth::user()->id)
            ->leftJoin('countries', 'countries.id', '=', 'users.country_id')
            ->get();

        $countries = Country::all();

        return view('user.account')->with(['data' => $user, 'countries' => $countries]);
    }

    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     * Вывод страницы регистрации
     */
    public function registrationPage()
    {
        $countries = Country::all();

        return view('user.registration')->with('countries', $countries);
    }

    public function resetPage()
    {
        return view('user.reset');
    }

    public function reset(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'last-password' => 'required|min:8|max:30',
            'new-password' => 'required|min:8|max:30|confirmed'
        ], [
            'required' => "Поле :attribute обязательно для заполнения",
            'min' => 'Недопустимая длина для поля :attribute',
            'max' => 'Недопустимая длина для поля :attribute',
            'confirmed' => 'Введенные пароли не совпадают'
        ]);

        if($validation->fails())
            return back()->withErrors($validation)->withInput();

        $password = User::where('id', Auth::user()->id)->get()->pluck('password')->first();

        if(!Hash::check(trim($request->input('last-password')), $password))
            return back()->withErrors(['last-password' => 'Неверный старый пароль'])->withInput();

        User::where('id', Auth::user()->id)
            ->update(['password' => Hash::make($request->input('new-password'))]);

        return back()->with('success', true);
    }

    /**
     * @param Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * Выход из профиля
     */
    public function logout(Request $request)
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect('/');
    }
}
