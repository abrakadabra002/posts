<?php

namespace App\Http\Controllers;

use App\Models\Post;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class PostController extends Controller
{
    public function all()
    {
        $posts = Post::leftJoin('users', 'users.id', '=', 'posts.user_id')
            ->orderByDesc('post_id')
            ->get();

        return view('home')->with('posts', $posts);
    }

    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     * Вывод страницы создания нового поста
     */
    public function createPage()
    {
        return view('post.create');
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse
     * Создание поста
     */
    public function create(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'title' => 'required|min:3|max:160',
            'text' => 'required|min:5',
            'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg,webp|max:2048'
        ],[
            'required' => 'Поле :attribute обязательно для заполнения',
            'min' => 'Недопустимая длина для поля :attribute',
            'max' => 'Недопустимая длина для поля :attribute',
            'mime' => 'Загружаемый имеет нежопустимый тип',
            'image' => 'Загружаемый файл не является изображением'
        ]);

        if($validation->fails())
            return back()->withErrors($validation)->withInput();


        $file = $request->file('image');

        $fileInfo = $file->getClientOriginalName();
        $filename = pathinfo($fileInfo, PATHINFO_FILENAME);

        $extension = $file->getClientOriginalExtension();

        $store = $filename . '_' . time() . '.' . $extension;
        $file->storeAs('public/', $store);

        $post = Post::create([
            'title' => $request->input('title'),
            'text' => $request->input('text'),
            'image' => $store,
            'user_id' => Auth::user()->id,
        ]);

        return back()->with(['success' => true, 'id' => $post->id]);
    }

    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View
     * Вывод страницы со всеми постами
     */
    public function postsPage()
    {
        $posts = Post::where('id', Auth::user()->id)
            ->leftJoin('users', 'posts.user_id', '=', 'users.id')
            ->orderByDesc('posts.post_id')
            ->get();

        return view('post.all')->with('posts', $posts);
    }

    public function delete(Request $request)
    {
        Post::where('post_id', $request->input('id'))->delete();

        return back()->with('delete', true);
    }

    public function updatePage($id)
    {
        $post = Post::where('post_id', $id)->first();

        return view('post.update')->with('post', $post);
    }

    public function post($id)
    {
        $post = Post::where('post_id', $id)
            ->leftJoin('users', 'users.id', '=', 'posts.user_id')
            ->first();

        return view('post.post')->with('post', $post);
    }

    public function update(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'title' => 'required|min:1|max:80',
            'text' => 'required|min:1'
        ],[
            'required' => 'Поле :attribute обязательно для заполнения',
            'min' => 'Недопустимая длина для поля :attribute',
            'max' => 'Недопустимая длина для поля :attribute',
        ]);

        if($validation->fails())
            return back()->withErrors($validation)->withInput();

        Post::where('post_id', $request->input('id'))
            ->update([
                'title' => $request->input('title'),
                'text' => $request->input('text')
            ]);

        return back()->with('update', true);
    }
}
