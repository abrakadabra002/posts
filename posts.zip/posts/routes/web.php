<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PostController;

Route::get('/', [PostController::class, 'all'])->name('home');
Route::get('/login', [UserController::class, 'loginPage'])->name('login');
Route::get('/registration', [UserController::class, 'registrationPage'])->name('registration');
Route::get('/post/one/{id}', [PostController::class, 'post'])->name('post');

Route::middleware('user.auth')->group(function () {
    Route::get('/post/create', [PostController::class, 'createPage'])->name('create');
    Route::get('/post/all', [PostController::class, 'postsPage'])->name('posts');
    Route::get('/post/edit', [PostController::class, 'updatePage'])->name('edit');
    Route::get('/account', [UserController::class, 'accountPage'])->name('account');
    Route::get('/account/reset', [UserController::class, 'resetPage'])->name('reset');
    Route::get('/logout', [UserController::class, 'logout'])->name('logout');
    Route::get('/post/edit/{id}', [PostController::class, 'updatePage'])->name('update');
});

Route::post('/login', [UserController::class, 'login']);
Route::post('/registration', [UserController::class, 'registration']);
Route::post('/account/edit', [UserController::class, 'account'])->name('edit');
Route::post('/account/reset', [UserController::class, 'reset']);
Route::post('/post/create', [PostController::class, 'create']);
Route::post('/post/delete', [PostController::class, 'delete'])->name('delete');
Route::post('/post/edit', [PostController::class, 'update'])->name('post-edit');
