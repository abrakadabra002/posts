@extends('welcome')

@section('content')
    <div class="container">
        <br><br>
        <a href="{{ route('home') }}" class="guest-link">&larr; Назад</a>
        <h2 class="section-title" style="max-width: 70%">{{ $post->title ?? '' }}</h2>
        <br>
        <div class="post">
            <img src="/public/storage/{{ $post->image }}" alt="Картинка поста" class="post__image">
            <br><br>
            <p class="post__text">{{ $post->text }}</p>
            <p class="post__publication">Автор: {{ $post->email }}</p>
            <p class="post__publication">Опубликовано: {{ $post->created_at }}</p>
        </div>
    </div>
@endsection
