@extends('welcome')

@section('content')
    <div class="container form-container">
        @auth
            <form action="{{ route('post-edit') }}" method="POST" class="form large-form">
                @csrf
                @if(session('update'))
                    <div class="success" style="margin-bottom: 10px">Изменения сохранены.&nbsp;<a href="{{ route('posts') }}" class="redirect-link" style="color: #fff">Перейти к моим постам</a></div>
                @endif
                <input type="hidden" name="id" value="{{ $post->post_id }}">
                <img src="/public/storage/{{ $post->image }}" alt="Картинка поста" class="large-form__image">
                <input type="text" name="title" placeholder="Заголовок" class="form__input @error('title') err-field @enderror" value="{{ $post->title }}">
                <textarea name="text" placeholder="Описание" class="form__input form__area @error('text') err-field @enderror">{{ $post->text }}</textarea>
                @if($errors)
                    <ul class="errors-list">
                        @foreach($errors->all() as $error)
                            <li class="errors-list__item">{{ $error }}</li>
                        @endforeach
                    </ul>
                @endif
                <button type="submit" class="form__button">Изменить</button>
            </form>
            <a href="{{ route('posts') }}" class="guest-link form-link">Мои посты</a>
        @endauth

        @guest
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="{{ route('home') }}" class="guest-link">&larr; На главную</a>
        @endguest
    </div>
@endsection
