@extends('welcome')

@section('content')
    <div class="container lk-container">
        @auth
            <div class="all-posts">
                <div class="top-section">
                    <h2 class="section-title">Мои посты</h2>
                </div>
                @if(session('delete'))
                    <div class="error" style="margin-bottom: 10px">Пост удален</div>
                @endif
                @foreach($posts->all() as $post)
                    <div class="post">
                        <img src="/public/storage/{{ $post->image }}" alt="Картинка поста" class="post__image">
                        <h2 class="post__title">{{ $post->title }}</h2>
                        <p class="post__text">{{ $post->text }}</p>
                        <p class="post__publication">Опубликовано: {{ $post->created_at }}</p>
                        <div class="option-block">
                            <form action="{{ route('update', ['id' => $post->post_id]) }}" method="GET">
                                <input type="hidden" name="id" value="{{ $post->post_id }}">
                                <button type="submit" class="option-btn">&#9998;</button>
                            </form>
                            <form action="{{ route('delete') }}" method="POST">
                                @csrf
                                <input type="hidden" name="id" value="{{ $post->post_id }}">
                                <button type="submit" class="option-btn">&#10006;</button>
                            </form>
                        </div>
                    </div>
                @endforeach
                @if(!count($posts))
                    <div class="no-content">У вас нет созданных постов. <a href="{{ route('create') }}" class="guest-link">Создать сейчас</a></div>
                @endif
            </div>
        @endauth

        @guest
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="{{ route('home') }}" class="guest-link">&larr; На главную</a>
        @endguest
    </div>
@endsection

