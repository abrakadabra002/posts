@extends('welcome')

@section('content')
    <div class="container form-container">
        @auth
            <form action="" method="POST" enctype="multipart/form-data" class="form large-form">
                @csrf
                <h2 class="form__title">Создать новый пост</h2>
                @if(session('success'))
                    <div class="success" style="margin-bottom: 10px">Пост опубликован. <a href="{{ route('post', ['id' => session('id')]) }}" class="redirect-link" style="color: #fff">Посмотреть</a></div>
                @endif
                <input type="text" name="title" placeholder="Заголовок" class="form__input @error('title') err-field @enderror" value="{{ old('title') ?? '' }}">
                <textarea name="text" placeholder="Описание" class="form__input form__area @error('text') err-field @enderror">{{ old('text') ?? '' }}</textarea>
                <input type="file" name="image" placeholder="Изображение" class="form__input @error('image') err-field @enderror">
                @if($errors)
                    <ul class="errors-list">
                        @foreach($errors->all() as $error)
                            <li class="errors-list__item">{{ $error }}</li>
                        @endforeach
                    </ul>
                @endif
                <button type="submit" class="form__button">Создать</button>
            </form>
            <a href="{{ route('account') }}" class="guest-link form-link">Назад в профиль</a>
        @endauth

        @guest
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="{{ route('home') }}" class="guest-link">&larr; На главную</a>
        @endguest
    </div>
@endsection
