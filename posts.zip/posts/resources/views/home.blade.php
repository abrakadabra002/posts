@extends('welcome')

@section('content')
    <div class="container">
        <h2 class="section-title">О компании</h2>
        <p class="about">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit.
            Aliquid aspernatur autem consequatur fugit iste odit quidem. Doloribus eos,
            id natus quam reiciendis sed? Accusamus aliquam aliquid eum fugit maiores
            molestiae, mollitia nam officiis pariatur quam quo ratione reiciendis rem sit!
        </p>
        <h2 class="section-title">Новые посты</h2>
        <br>
        @foreach($posts->all() as $post)
            <div class="post">
                <img src="/public/storage/{{ $post->image }}" alt="Картинка поста" class="post__image">
                <h2 class="post__title">{{ $post->title }}</h2>
                <p class="post__text overflow-text">{{ $post->text }}</p>
                <p class="post__publication">Автор: {{ $post->email }}</p>
                <p class="post__publication">Опубликовано: {{ $post->created_at }}</p>
                <a href="{{ route('post', ['id' => $post->post_id]) }}" class="about-link">Подробнее</a>
            </div>
        @endforeach
    </div>
@endsection
