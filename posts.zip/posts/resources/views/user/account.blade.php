@extends('welcome')

@section('content')
    <div class="container lk-container">
        @auth
        <div class="lk-form">
            <h2 class="section-title">Личный кабинет</h2>
            <form action="{{ route('edit') }}" method="POST" class="form edit-form">
                @csrf
                @if(session('success'))
                    <div class="success" style="margin-bottom: 15px">Изменения успешно сохранены</div>
                @endif
                @foreach($data as $user)
                    <div class="form-element">
                        <div class="form-element__title">Адрес электронной почты</div>
                        <input type="text" class="form__input disabled-input" value="{{ $user->email }}" disabled>
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Страна происхождения</div>
                        <select name="country" id="country" class="form__input">
                            @foreach($countries as $country)
                                <option value="{{ $country->id }}" {{ $country->id == $user->country_id ? 'selected' : '' }}>{{ $country->country }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Дата рождения</div>
                        <input type="date" name="birthdate" class="form__input" value="{{ $user->birthdate }}">
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Наличие лицензии</div>
                        <input type="text" class="form__input disabled-input" value="{{ $user->licence ? 'Лицензия активна' : '' }}" disabled>
                    </div>
                    <div class="form-element">
                        <div class="form-element__title">Наличие регистрации</div>
                        <input type="text" class="form__input disabled-input" value="{{ $user->registration ? 'Зарегистрирован' : '' }}" disabled>
                    </div>
                    <button type="submit" class="form__button">Сохранить изменения &rarr;</button>
                    <br>
                    <a href="{{ route('reset') }}" class="guest-link">Изменить пароль</a>
                @endforeach
            </form>
        </div>
        <div class="lk-actions">
            <a href="{{ route('create') }}" class="lk-actions__link">Создать пост &rarr;</a>
            <a href="{{ route('posts') }}" class="lk-actions__link">Мои посты &rarr;</a>
        </div>
        @endauth

        @guest
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="{{ route('home') }}" class="guest-link">&larr; На главную</a>
        @endguest
    </div>
@endsection

