@extends('welcome')

@section('content')
    <div class="container form-container">
        @auth
        <form action="" method="POST" class="form">
            @csrf
            <h2 class="form__title">Изменить пароль</h2>
            @if(session('success'))
                <div class="success" style="margin-bottom: 10px">Пароль успешно изменен</div>
            @endif
            <input type="password" name="last-password" placeholder="Предыдущий пароль" class="form__input @error('last-password') err-field @enderror" value="{{ old('last-password') }}">
            <input type="password" name="new-password" placeholder="Новый пароль" class="form__input @error('new-password') err-field @enderror" value="{{ old('new-password') }}">
            <input type="password" name="new-password_confirmation" placeholder="Повторите новый пароль" class="form__input @error('new-password') err-field @enderror" value="{{ old('new-password_confirmation') }}">
            @if($errors)
                <ul class="errors-list">
                    @foreach($errors->all() as $error)
                        <li class="errors-list__item">{{ $error }}</li>
                    @endforeach
                </ul>
            @endif
            <button type="submit" class="form__button">Сохранить</button>
        </form>
        <a href="{{ route('account') }}" class="guest-link form-link">Назад в профиль</a>
        @endauth

        @guest
            <p class="guest-title">Данная страница доступна только для зарегистрированных пользователей</p>
            <a href="{{ route('home') }}" class="guest-link">&larr; На главную</a>
        @endguest
    </div>
@endsection
