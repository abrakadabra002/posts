@extends('welcome')

@section('content')
    <div class="container form-container">
        <form action="" method="POST" class="form" id="login-form">
            @csrf
            <h2 class="form__title">Регистрация</h2>
            <input type="email" name="email" placeholder="Адрес электронной почты" class="form__input @error('email') err-field @enderror" value="{{ old('email') }}">
            <input type="text" name="birthdate" placeholder="Дата рождения" class="form__input @error('birthdate') err-field @enderror" onclick="this.type='date'" value="{{ old('birthdate') }}">
            <select name="country" id="country" class="form__input @error('country') err-field @enderror" value="{{ old('country') }}">
                <option value="0" disabled selected>Выбрать страну</option>
                @foreach($countries as $country)
                    <option value="{{ $country->id }}">{{ $country->country }}</option>
                @endforeach
            </select>
            <input type="password" name="password" placeholder="Пароль" class="form__input @error('password') err-field @enderror" value="{{ old('password') }}">
            <input type="password" name="password_confirmation" placeholder="Повтроите пароль" class="form__input @error('password_confirmation') err-field @enderror" value="{{ old('password_confirmation') }}">
            <div class="checkbox-block">
                <span>Наличие водительских прав <input type="checkbox" name="licence" value="1"></span>
                <span>Наличие регистрации <input type="checkbox" name="registration" value="1"></span>
            </div>
            <div class="more-action">
                <a href="{{ route('login') }}" class="more-action__link">Войти</a>
            </div>
            @if($errors)
                <ul class="errors-list">
                    @foreach($errors->all() as $error)
                        <li class="errors-list__item">{{ $error }}</li>
                    @endforeach
                </ul>
            @endif
            @if(session('registration'))
                <div class="success">Вы успешно зарегистрировались. <a href="{{ route('login') }}" class="success-link">Войти</a></div>
            @endif
            <button type="submit" class="form__button">Зарегистрироваться</button>
        </form>
    </div>
@endsection

