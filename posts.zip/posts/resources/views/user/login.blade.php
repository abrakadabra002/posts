@extends('welcome')

@section('content')
    <div class="container form-container">
        <form action="" method="POST" class="form" id="login-form">
            @csrf
            <h2 class="form__title">Авторизация</h2>
            <input type="email" name="email" placeholder="Адрес электронной почты" class="form__input @error('email') err-field @enderror" value="{{ old('email') }}">
            <input type="password" name="password" placeholder="Пароль" class="form__input @error('password') err-field @enderror" value="{{ old('password') }}">
            <div class="error-block" style="display: none">fdgdf</div>
            <div class="more-action">
                <a href="{{ route('registration') }}" class="more-action__link">Зарегистрироваться</a>
            </div>
            @if($errors || session()->has('error'))
                <ul class="errors-list">
                    @foreach($errors->all() as $error)
                        <li class="errors-list__item">{{ $error }}</li>
                    @endforeach
                    @if(session()->has('error'))
                        <li class="errors-list__item">Неверный логин или пароль</li>
                    @endif
                </ul>
            @endif
            <button type="submit" class="form__button">Войти</button>
        </form>
    </div>
@endsection
